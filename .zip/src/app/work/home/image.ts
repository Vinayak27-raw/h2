export class Card {

    link:string;

    title:string;

    text:string;

    host:string;

    time:string;

}