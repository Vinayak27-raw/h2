import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  registerForm:FormGroup;




  constructor(private builder:FormBuilder){}

 

  //using Form Builder

  ngOnInit(): void {

    this.registerForm = this.builder.group({

      firstname:[null,[Validators.required,Validators.minLength(3)]],

      lastname:[null,[Validators.required,Validators.minLength(3)]],

      mblno:[null,Validators.pattern("^[9876][0-9]{9}$")],

      email:[null,[Validators.required,Validators.email]],

      password:[null,Validators.required],

      confirmPassword:[null, Validators.required]

    });

  }




  onSubmit(){

    console.log(this.registerForm.value);

  }

}

