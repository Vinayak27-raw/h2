import { EventService } from './../event.service';
import { Event } from './../event';
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-update-event',
  templateUrl: './update-event.component.html',
  styleUrls: ['./update-event.component.css']
})
export class UpdateEventComponent {

  event:any;

  constructor(private eventService:EventService,
    private route:ActivatedRoute,private router:Router){}

  ngOnInit(){

    const id=this.route.snapshot.params["id"];
    console.log(id)
   
    this.event=this.eventService.getEventId(id);
   
  }
  onUpdate(emp:Event){
    console.log(emp);
    this.eventService.updateEvent(emp);
    this.router.navigate(["/event"])

  }
 
}
