import { EventService } from './../event.service';
import { Event } from './../event';
import { Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgFor } from '@angular/common';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-add-event',
  templateUrl: './add-event.component.html',
  styleUrls: ['./add-event.component.css']
})
export class AddEventComponent {


  @ViewChild("empForm")
  eventForm:NgForm

  constructor(private eventService:EventService,
    private router:Router){}

   onAdd(event:Event){
    this.eventService.addEvent(event);
    this.router.navigate(["/event"])
  }


}