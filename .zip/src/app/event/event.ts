export interface Event {
    id:number,
    name:string,
    desc:string,
    speaker:string,
    agenda:string,
    reg:string,
    social:string
}