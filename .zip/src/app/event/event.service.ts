import { Injectable } from "@angular/core";
import { Event } from './event';

@Injectable({
    providedIn: 'root'
  })
  export class EventService {
  
    events:Event[]=[
      {id:1,name:"Anugular Conf" ,desc:"Confrence On Angular",speaker:'Dr.Thomas' ,agenda:'Angular' ,reg:'#' ,social:'#'},
      {id:2,name:"React Library",desc:"Confrence On Angular",speaker:'Dr.Jain' ,agenda:'React' ,reg:'#' ,social:'#'},
      {id:3,name:"Testing ",desc:"Confrence On Angular",speaker:'Mr.Hari' ,agenda:'Test' ,reg:'#' ,social:'#'},
      {id:4,name:"Hackathon",desc:"Confrence On Angular",speaker:'Mr.James' ,agenda:'Hackathons' ,reg:'#' ,social:'#'},
      {id:5,name:"Frontend Library",desc:"Confrence On Angular",speaker:'Dr.Rai' ,agenda:'Frontend' ,reg:'#' ,social:'#'},
    ]
  
    constructor() { }
  
    addEvent(event:Event){
      this.events.push(event)
    }
  
    getEventId(id:any){
      return this.events.find(e=>e.id==id);
    }
  
    updateEvent(event:Event){
      let newEvents=this.events.filter(e=>e.id!=event.id);
      newEvents=[...newEvents,event];
      newEvents.sort((a,b)=>a.id-b.id)
      this.events=newEvents;
      console.log("updated completed")
      
    }  
  
    deleteEvent(id:number){
      this.events=this.events.filter(emp=>emp.id!=id);
      console.log(this.events)
    }
}