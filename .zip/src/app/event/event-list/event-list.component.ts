import { Component, numberAttribute } from '@angular/core';
import { Router } from '@angular/router';
import { EventService } from './../event.service';
import { Event } from './../event';

@Component({
  selector: 'app-event-list',
  templateUrl: './event-list.component.html',
  styleUrls: ['./event-list.component.css']
})
export class EventListComponent {

  selectedValue:string="All"

  events:Event[];

  constructor(private eventService:EventService
    ,private router:Router){}

  ngOnInit(){
    this.events=this.eventService.events;
  }

  onUpdate(id:number){
    this.router.navigate(["/update", id])
  }

  onDelete(event:Event){
    let response=confirm(`Do you wish to delete employee ${event.id}`)
    if(response){
      this.eventService.deleteEvent(event.id);
    }
    this.events=this.eventService.events;
    this.router.navigate(["/event"])
    
  }


}
